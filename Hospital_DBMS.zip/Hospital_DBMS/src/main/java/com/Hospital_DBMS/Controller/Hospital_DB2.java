package com.Hospital_DBMS.Controller;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns="/Hospital_DB2")
public class Hospital_DB2 extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public Hospital_DB2() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		String driverName = "com.mysql.jdbc.Driver";
		String connectionUrl = "jdbc:mysql://localhost:3306/";
		String dbName = "Hospital_Management_System";
		String userId = "root";
		String password = "Root";
		String pwdd=null;
		String name=request.getParameter("userName");
	
		String psswd=request.getParameter("password");
		try {
			Class.forName(driverName);
			} catch (ClassNotFoundException e) {
				System.out.println("sadasd");
			e.printStackTrace();
			}

			Connection connection = null;
			Statement statement = null;
			ResultSet resultSet = null;
			try{ 
				connection = DriverManager.getConnection(connectionUrl+dbName, userId, password);
				statement=connection.createStatement();
				String sql ="SELECT D_O_B FROM Manage_Patient where name='"+name+"Saurabh";

				resultSet = statement.executeQuery(sql);
				while(resultSet.next()) {
				pwdd=resultSet.getString("password");
				}
		if(psswd.equalsIgnoreCase(pwdd)) 
		{
			session.setAttribute("Name",name);
			request.getRequestDispatcher("patientpage.jsp").forward(request, response);
		}
	
		else
		{
			request.setAttribute("error", "Invalid username/password.");
			request.getRequestDispatcher("plogin.jsp").forward(request, response);
	    }
	}
			catch(SQLException e) 
			{ 
		       System.out.println("kkrk");
		       e.printStackTrace();
	}
			}
	}