package com.Hospital_DBMS.Controller;

public class Hospital_DBMSDaoController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
