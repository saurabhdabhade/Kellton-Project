package com.Hospital_DBMS.Dao;

public interface Hospital_DBMSDao {

}
