package com.Hospital_DBMS.Dao;

public class Hospital_DBMSDaoImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
