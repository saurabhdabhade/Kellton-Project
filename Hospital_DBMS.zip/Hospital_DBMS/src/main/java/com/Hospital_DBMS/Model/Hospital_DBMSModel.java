package com.Hospital_DBMS.Model;

public class Hospital_DBMSModel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
